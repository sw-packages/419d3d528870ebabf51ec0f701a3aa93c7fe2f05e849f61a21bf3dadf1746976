// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (C) 2017-2019 Egor Pugin <egor.pugin@gmail.com>

#include <string>

extern const std::string sw_config_cmake;
extern const std::string project_templates;
